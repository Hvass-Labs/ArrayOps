//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Variance
//
//	Computes and returns the variance of an array's elements.
//	This is also called the Population Variance.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Functions/Reduce.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Example: double var = Variance(A);

	template <typename T, class S> inline
	double Variance(Expr<T,S> const& x)
	{
		return Reduce<double>::Variance(x);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
