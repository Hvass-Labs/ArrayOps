//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Norm
//
//	Computes and returns the Euclidian (or L2) norm of an array's elements.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Functions/Reduce.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Example: double nrm = Norm(A);

	template <typename T, class S> inline
	double Norm(Expr<T,S> const& x)
	{
		return Reduce<double>::Norm(x);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
