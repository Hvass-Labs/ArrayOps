//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Reduce
//
//	A class implementing various reductions whose return-types may
//	be different from the argument-types.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Functions/Sum.h>
#include <cmath>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Example: long double avg = Reduce<long double>::Mean(A);

	template <typename TRes=double>
	class Reduce
	{
	public:
		// Mean
		template <typename TArg, class S>
		static inline
		TRes Mean(Expr<TArg,S> const& x)
		{
			assert(x.IsSized());
			assert(x.Size()>0);

			return ((TRes) Sum(x))/x.Size();
		};

		// Norm
		template <typename TArg, class S>
		static inline
		TRes Norm(Expr<TArg,S> const& x)
		{
			return std::sqrt((TRes) Sum(pow2(x)));
		};

		// Variance
		template <typename TArg, class S>
		static inline
		TRes Variance(Expr<TArg,S> const& x)
		{
			assert(x.IsSized());
			assert(x.Size()>0);

			TRes mean = Mean(x);
			TRes sum = Sum(pow2(StaticCast<TRes>(x)-mean));

			return sum/x.Size();
		};
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
