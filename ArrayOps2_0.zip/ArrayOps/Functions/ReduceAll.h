//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ReduceAll
//
//	Functions for making reductions using functor objects.
//	The functor objects are either provided by the user,
//	or instantiated in the ReduceAll functions themselves.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr.h>
#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Functor instance provided.
	// Note that functor is of course not const.
	// Example: int s = ReduceAll(A, Sum<int>());

	// Note that the returned value could have been a
	// const-reference, if we were sure that the functor
	// returned a reference. But since we can not know
	// that for sure, we must return a value from the
	// ReduceAll-functions, to ensure that we are not
	// referencing garbage after returning from ReduceAll.

	template <class F, class T, class S>
	T ReduceAll(Expr<T, S> const& x, F& f)
	{
		assert(x.IsSized());
		const unsigned int kSize = x.Size();

		for (unsigned int i=0; i<kSize; i++)
		{
			f(x[i]);
		}

		return f();
	}

	// Different argument and return types.
	template <class TRes, class TArg, class F, class S>
	TRes ReduceAll(Expr<TArg, S> const& x, F& f)
	{
		assert(x.IsSized());
		const unsigned int kSize = x.Size();

		for (unsigned int i=0; i<kSize; i++)
		{
			f(x[i]);
		}

		return f();
	}

//....................................................................................................................................................................................

	// Functor instance not provided.
	// Example: int s = ReduceAll<Sum<int> >(A);

	// Note that we must return a value from these functions,
	// because the local functor object is of course destroyed
	// upon returning from the ReduceAll functions.

	template <class F, class T, class S>
	T ReduceAll(Expr<T, S> const& x)
	{
		assert(x.IsSized());
		const unsigned int kSize = x.Size();

		F f;

		for (unsigned int i=0; i<kSize; i++)
		{
			f(x[i]);
		}

		return f();
	}

	// Different argument and return types.
	template <class F, class TRes, class TArg, class S>
	TRes ReduceAll(Expr<TArg, S> const& x)
	{
		assert(x.IsSized());
		const unsigned int kSize = x.Size();

		F f;

		for (unsigned int i=0; i<kSize; i++)
		{
			f(x[i]);
		}

		return f();
	}

//....................................................................................................................................................................................
} //end namespace ArrayOps
