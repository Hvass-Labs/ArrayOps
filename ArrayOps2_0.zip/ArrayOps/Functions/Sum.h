//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Sum
//
//	Computes and returns the sum of an array's elements.
//	It uses the Accumulator functor with the addition operator.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Functions/ReduceAll.h>
#include <ArrayOps/Tools/Accumulator.h>
#include <ArrayOps/Tools/Functional.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Example: int s = Sum(A);

	template <typename T, class S> inline
	T Sum(Expr<T,S> const& x)
	{
		return ReduceAll(x, Accumulator<T, assign_plus<T> >(0));
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
