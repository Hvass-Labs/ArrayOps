//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Mean
//
//	Computes and returns the average or mean-value of an array's elements.
//	This is also called the Arithmetic Mean.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Functions/Reduce.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Example: double avg = Mean(A);

	template <typename T, class S> inline
	double Mean(Expr<T,S> const& x)
	{
		return Reduce<double>::Mean(x);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
