//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Eval1
//
//	Helper-functions for evaluating unary user-functions for each
//	element in an array.
//
//	Note the ordering of expressions and functors/function-pointers,
//	which can not be reversed, as the template-arguments can not be
//	deduced otherwise.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr1.h>
#include <ArrayOps/Tools/Functional.h>

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Functor instance.
	// Example: A = Eval(C, std::negate<double>());

	template <typename T, class F, class S>
	Expr1<T, F, false, Expr<T, S>, false>
	Eval1(Expr<T, S> const& expr, F const& f)
	{
		return Expr1<T, F, false, Expr<T, S>, false>(expr, f);
	};

	// Different argument and return types.
	template <typename TRes, typename TArg, class F, class S>
	Expr1<TRes, F, false, Expr<TArg, S>, false>
	Eval1(Expr<TArg, S> const& expr, F const& f)
	{
		return Expr1<TRes, F, false, Expr<TArg, S>, false>(expr, f);
	};

//....................................................................................................................................................................................

	// Functor, but no instance.
	// Example: A = Eval<std::negate<double> >(C);

	template <class F, typename T, class S>
	Expr1<T, F, true, Expr<T, S>, false>
	Eval1(Expr<T, S> const& expr)
	{
		return Expr1<T, F, true, Expr<T, S>, false>(expr);
	};

	// Different argument and return types.
	template <class F, typename TRes, typename TArg, class S>
	Expr1<TRes, F, true, Expr<TArg, S>, false>
	Eval1(Expr<TArg, S> const& expr)
	{
		return Expr1<TRes, F, true, Expr<TArg, S>, false>(expr);
	};

//....................................................................................................................................................................................

	// Pointer to function.
	// Example: A = Eval(C, &std::sqrt);

	template <typename T, class S>
	Expr1<T, std::pointer_to_unary_function<T, T>, true, Expr<T, S>, false>
	Eval1(Expr<T, S> const& expr, T (*f)(T))
	{
		return Expr1<T, std::pointer_to_unary_function<T, T>, true, Expr<T, S>, false>(expr, std::pointer_to_unary_function<T, T>(f));
	};

	// Different argument and return types.
	template <typename TRes, typename TArg, class S>
	Expr1<TRes, std::pointer_to_unary_function<TArg, TRes>, true, Expr<TArg, S>, false>
	Eval1(Expr<TArg, S> const& expr, TRes (*f)(TArg))
	{
		return Expr1<TRes, std::pointer_to_unary_function<TArg, TRes>, true, Expr<TArg, S>, false>(expr, std::pointer_to_unary_function<TArg, TRes>(f));
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
