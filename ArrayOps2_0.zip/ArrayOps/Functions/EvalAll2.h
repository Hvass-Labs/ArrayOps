//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	EvalAll2
//
//	Functions that are presently used for the looped assignments.
//	Left-hands must be ArrayBase-objects, and right-hands can be
//	any Expr-object.
//
//	Special versions of these functions are provided for left-hand
//	arguments that are ArrayAuto-objects. These functions will first
//	resize the left-hand arrays to match the size of the right-hand
//	expressions, then copy the original array-elements; and finally
//	perform the desired operation.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/MatchingSize.h>
#include <ArrayOps/Tools/Functional.h>
#include <ArrayOps/Tools/Forward.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Right-hand is an ArrayOps expression.

	// Parallel version.
	template <class Op, class T, class S1, class S2> inline
	void
	EvalAll(ArrayBase<T, S1, true>& arr, Expr<T, S2> const& expr)
	{
		assert(MatchingSize(arr, expr));

		const Op op;
		const int kSize = (int) arr.Size();

		#pragma omp parallel for if (kSize>=arr.GetParLimit())
		for (int i=0; i<kSize; i++)
		{
			op(arr[i], expr[i]);
		}
	}

	// Non-parallel version.
	template <class Op, class T, class S1, class S2>
	void
	EvalAll(ArrayBase<T, S1, false>& arr, Expr<T, S2> const& expr)
	{
		assert(MatchingSize(arr, expr));

		const Op op;
		const int kSize = (int) arr.Size();

		for (int i=0; i<kSize; i++)
		{
			op(arr[i], expr[i]);
		}
	}

//....................................................................................................................................................................................

	// Right-hand is a value.

	// Parallel version.
	template <class Op, class T, class S1>
	void
	EvalAll(ArrayBase<T, S1, true>& arr, T const& val)
	{
		const Op op;
		const int kSize = (int) arr.Size();

		#pragma omp parallel for if (kSize>=arr.GetParLimit())
		for (int i=0; i<kSize; i++)
		{
			op(arr[i], val);
		}
	}

	// Non-parallel version.
	template <class Op, class T, class S1>
	void
	EvalAll(ArrayBase<T, S1, false>& arr, T const& val)
	{
		const Op op;
		const int kSize = (int) arr.Size();

		for (int i=0; i<kSize; i++)
		{
			op(arr[i], val);
		}
	}

//....................................................................................................................................................................................
} //end namespace ArrayOps
