//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeOperatorLogical1
//
//	Same as MakeFunction1, only the return-type is a boolean.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Macros/AOp_MakeFunction1.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

#define AOp_MakeOperatorLogical1(NAME, FUNCTOR) \
	AOp_MakeFunction1(bool, NAME, FUNCTOR);

//....................................................................................................................................................................................
} //end namespace ArrayOps
