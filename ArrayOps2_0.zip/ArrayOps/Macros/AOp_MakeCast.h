//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeCast
//
//	A macro for making a casting-style function. That is, a function
//	which takes one type for its argument, and another type for its return-value.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr1.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	#define AOp_MakeCast(NAME, FUNCTOR) \
		template <typename TRes, typename TArg, class S> \
		Expr1<TRes, FUNCTOR##<TRes, TArg>, true, Expr<TArg, S>, false> \
		NAME (Expr<TArg, S> const& expr) \
		{ \
			return Expr1<TRes, FUNCTOR##<TRes, TArg>, true, Expr<TArg, S>, false>(expr); \
		};

//....................................................................................................................................................................................
} //end namespace ArrayOps
