//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeOperatorPtr2
//
//	Same as MakeFunctionPtr2, only the return-type is the same as the argument-type.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Macros/AOp_MakeFunctionPtr2.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

#define AOp_MakeOperatorPtr2(NAME, FUNPTR) \
	AOp_MakeFunctionPtr2(T, NAME, FUNPTR);

//....................................................................................................................................................................................
} //end namespace ArrayOps
