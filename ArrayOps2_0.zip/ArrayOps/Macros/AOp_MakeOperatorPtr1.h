//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeOperatorPtr1
//
//	Same as MakeFunctionPtr1, only the return-type is the same as the argument-type.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Macros/AOp_MakeFunctionPtr1.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

#define AOp_MakeOperatorPtr1(NAME, FUNPTR) \
	AOp_MakeFunctionPtr1(T, NAME, FUNPTR);

//....................................................................................................................................................................................
} //end namespace ArrayOps
