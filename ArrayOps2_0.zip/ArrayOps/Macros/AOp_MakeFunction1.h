//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeFunction1
//
//	The operator overloadings used for iteratively creating new unary
//	expressions out of other sub-expressions.
//
//	In these macros, the return-type is determined by a macro-argument.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr1.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

// This is the overloading of the unary operator (e.g. negation), which takes as parameter
// an Expr<T,S> object, and returns another expression-object, which is to apply
// the given operator to the former.
// Note that it is not necessary to store a copy of the former object (as indicated
// by the 'false' booleans).

#define AOp_MakeFunction1Expr(RESTYPE, NAME, FUNCTOR) \
	template <typename T, class S> \
	Expr1<RESTYPE, FUNCTOR##<T>, true, Expr<T, S>, false> \
	NAME (Expr<T, S> const& x) \
	{ \
		return Expr1<RESTYPE, FUNCTOR##<T>, true, Expr<T, S>, false>(x); \
	};

//....................................................................................................................................................................................

// Use this macro to make unary operator overloadings.

#define AOp_MakeFunction1(RESTYPE, NAME, FUNCTOR) \
	AOp_MakeFunction1Expr(RESTYPE, NAME, FUNCTOR);

//....................................................................................................................................................................................
} //end namespace ArrayOps
