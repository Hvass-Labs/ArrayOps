//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeAssignAuto
//
//	Macros for creating assignment-style functions. That is, overloadings
//	of the functions operator=, operator+=, etc. The macro is to be used
//	inside an array-class.
//
//	This macro is for automatically resizable arrays. That is, for the
//	ArrayAuto class. Note that the macros do not have this class-name
//	hard-coded, and in fact, the macros may be used for the Array-class
//	as well! This you should not do, however, as the Array-class is not
//	supposed to be automatically resizable.
//
//	The macros assume that the array-class in question, provides two
//	functions for resizing the array: Resize() and ResizeCopy(), each
//	taking the new array-size as parameter. Resize() is used for overwriting
//	assignment where we do not need to copy the elements, and ResizeCopy()
//	is used for accumulative assignments (e.g. +=, *=, etc.), where the
//	array-elements must first be copied.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/Forward.h>
#include <ArrayOps/Functions/EvalAll2.h>
#include <ArrayOps/Tools/Functional.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The macro parameters are as follows:

	// ARRAY is the name of the array-class, e.g. ArrayAuto.
	// OPNAME is the name of the operator, e.g. operator=.
	// FUNCTOR is the name of the functor, e.g. assign.
	// RESIZE is the function for resizing, e.g. Resize or ResizeCopy.

//....................................................................................................................................................................................

// Assignment from same class.

#define AOp_MakeAssignAutoSame(ARRAY, OPNAME, FUNCTOR, RESIZE) \
	ARRAY & \
	OPNAME (ARRAY const& x) \
	{ \
		assert(x.IsSized()); \
		if (Size() != x.Size()) \
		{ \
			RESIZE##(x.Size()); \
		} \
		EvalAll<FUNCTOR##<T> >(*this, x); \
		return *this; \
	};

//....................................................................................................................................................................................

// Assignment from an Expr-object.

#define AOp_MakeAssignAutoExpr(ARRAY, OPNAME, FUNCTOR, RESIZE) \
	template <class S1> \
	ARRAY & \
	OPNAME (Expr<T, S1> const& x) \
	{ \
		assert(x.IsSized()); \
		if (Size() != x.Size()) \
		{ \
			RESIZE##(x.Size()); \
		} \
		EvalAll<FUNCTOR##<T> >(*this, x); \
		return *this; \
	};

//....................................................................................................................................................................................

// Assignment from a value or variable. Note the value is used immediately,
// and there is hence no need for copying it if it was a constant value.
// Note that this is identical to AOp_MakeAssignVal.

#define AOp_MakeAssignAutoVal(ARRAY, OPNAME, FUNCTOR, RESIZE) \
	ARRAY & \
	OPNAME (T const& x) \
	{ \
		EvalAll<FUNCTOR##<T> >(*this, x); \
		return *this; \
	};

//....................................................................................................................................................................................

// This macro is for accumulative operators, such as +=, *=, etc.
#define AOp_MakeAccumulateAuto(ARRAY, OPNAME, FUNCTOR) \
	AOp_MakeAssignAutoExpr(ARRAY, OPNAME, FUNCTOR, ResizeCopy); \
	AOp_MakeAssignAutoVal(ARRAY, OPNAME, FUNCTOR, ResizeCopy);

// This macro is for overwriting operators, such as assignment via =.
#define AOp_MakeOverwriteAuto(ARRAY, OPNAME, FUNCTOR) \
	AOp_MakeAssignAutoSame(ARRAY, OPNAME, FUNCTOR, Resize); \
	AOp_MakeAssignAutoExpr(ARRAY, OPNAME, FUNCTOR, Resize); \
	AOp_MakeAssignAutoVal(ARRAY, OPNAME, FUNCTOR, Resize);

//....................................................................................................................................................................................

// Use this macro to make assignment operator overloadings inside a class.

#define AOp_MakeAssignAuto(ARRAY) \
	AOp_MakeOverwriteAuto(ARRAY,  operator=,   assign); \
	AOp_MakeAccumulateAuto(ARRAY, operator+=,  assign_plus); \
	AOp_MakeAccumulateAuto(ARRAY, operator-=,  assign_minus); \
	AOp_MakeAccumulateAuto(ARRAY, operator*=,  assign_multiplies); \
	AOp_MakeAccumulateAuto(ARRAY, operator/=,  assign_divides); \
	AOp_MakeAccumulateAuto(ARRAY, operator%=,  assign_modulus); \
	AOp_MakeAccumulateAuto(ARRAY, operator&=,  assign_bitwise_and); \
	AOp_MakeAccumulateAuto(ARRAY, operator|=,  assign_bitwise_or); \
	AOp_MakeAccumulateAuto(ARRAY, operator^=,  assign_bitwise_xor); \
	AOp_MakeAccumulateAuto(ARRAY, operator<<=, assign_bitwise_lshift); \
	AOp_MakeAccumulateAuto(ARRAY, operator>>=, assign_bitwise_rshift);

//....................................................................................................................................................................................
} //end namespace ArrayOps
