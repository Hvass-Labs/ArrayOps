//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeFunctionPtr2
//
//	Similar to MakeFunction2, only this version takes pointers to functions instead
//	of functor-classes.
//
//	In these macros, the return-type is determined by a macro-argument.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/ExprVal.h>
#include <ArrayOps/Framework/ExprVar.h>
#include <ArrayOps/Framework/Expr1.h>
#include <ArrayOps/Framework/Expr2.h>

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

// This is the basic iterative case where both left- and right-hand operands
// are Expr<T,S> objects.
// Note that the expressions are not copied! (As indicated by all the 'false' booleans).

#define AOp_MakeFunctionPtrExprExpr(RESTYPE, NAME, FUNPTR) \
	template <typename T, class S1, class S2> \
	Expr2<	RESTYPE, \
			std::pointer_to_binary_function<T, T, RESTYPE>, true, \
			Expr<T, S1>, false, \
			Expr<T, S2>, false> \
	NAME (Expr<T, S1> const& l, Expr<T, S2> const& r) \
	{ \
		return Expr2<	RESTYPE, \
						std::pointer_to_binary_function<T, T, RESTYPE>, true, \
						Expr<T, S1>, false, \
						Expr<T, S2>, false>(l, r, std::pointer_to_binary_function<T, T, RESTYPE>(FUNPTR)); \
	};

//....................................................................................................................................................................................

// These are the special cases when either the left- or right-hand operands
// are constants (e.g. the value 10.0 if T=double, or return-values from a function).

// Note that both the Expr0-objects as well as the constant values must be copied
// (as indicated by the 'true'-booleans). This is because of C++ semantics, where the
// Expr0-objects and the constants are destroyed upon return of these operator-functions.

#define AOp_MakeFunctionPtrExprVal(RESTYPE, NAME, FUNPTR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			std::pointer_to_binary_function<T, T, RESTYPE>, true, \
			Expr<T, S>, false, \
			ExprVal<T>, true> \
	NAME (Expr<T, S> const& l, T const& r) \
	{ \
		return Expr2<	RESTYPE, \
						std::pointer_to_binary_function<T, T, RESTYPE>, true, \
						Expr<T, S>, false, \
						ExprVal<T>, true>(l, ExprVal<T>(r), std::pointer_to_binary_function<T, T, RESTYPE>(FUNPTR)); \
	};

#define AOp_MakeFunctionPtrValExpr(RESTYPE, NAME, FUNPTR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			std::pointer_to_binary_function<T, T, RESTYPE>, true, \
			ExprVal<T>, true, \
			Expr<T, S>, false> \
	NAME (T const& l, Expr<T, S> const& r) \
	{ \
		return Expr2<	RESTYPE, \
						std::pointer_to_binary_function<T, T, RESTYPE>, true, \
						ExprVal<T>, true, \
						Expr<T, S>, false>(ExprVal<T>(l), r, std::pointer_to_binary_function<T, T, RESTYPE>(FUNPTR)); \
	};

//....................................................................................................................................................................................

// These are the special cases when either the left- or right-hand operands
// are variables.

// Note that only the Expr0-objects are copied (as indicated by the 'true'-booleans),
// and the value of the variable is assumed to be unchanged for the duration of the
// computation, and we may therefore avoid using storage for it again. However, the
// Expr0-objects are of course still destroyed upon return of these operator-functions.

#define AOp_MakeFunctionPtrExprVar(RESTYPE, NAME, FUNPTR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			std::pointer_to_binary_function<T, T, RESTYPE>, true, \
			Expr<T, S>, false, \
			ExprVar<T>, true> \
	NAME (Expr<T, S> const& l, T& r) \
	{ \
		return Expr2<	RESTYPE, \
						std::pointer_to_binary_function<T, T, RESTYPE>, true, \
						Expr<T, S>, false, \
						ExprVar<T>, true>(l, ExprVar<T>(r), std::pointer_to_binary_function<T, T, RESTYPE>(FUNPTR)); \
	};

#define AOp_MakeFunctionPtrVarExpr(RESTYPE, NAME, FUNPTR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			std::pointer_to_binary_function<T, T, RESTYPE>, true, \
			ExprVar<T>, true, \
			Expr<T, S>, false> \
	NAME (T& l, Expr<T, S> const& r) \
	{ \
		return Expr2<	RESTYPE, \
						std::pointer_to_binary_function<T, T, RESTYPE>, true, \
						ExprVar<T>, true, \
						Expr<T, S>, false>(ExprVar<T>(l), r, std::pointer_to_binary_function<T, T, RESTYPE>(FUNPTR)); \
	};

//....................................................................................................................................................................................

// Use this macro to make binary operator overloadings.

#define AOp_MakeFunctionPtr2(RESTYPE, NAME, FUNPTR) \
	AOp_MakeFunctionPtrExprExpr(RESTYPE, NAME, FUNPTR); \
	AOp_MakeFunctionPtrExprVar(RESTYPE, NAME, FUNPTR); \
	AOp_MakeFunctionPtrVarExpr(RESTYPE, NAME, FUNPTR); \
	AOp_MakeFunctionPtrExprVal(RESTYPE, NAME, FUNPTR); \
	AOp_MakeFunctionPtrValExpr(RESTYPE, NAME, FUNPTR);

//....................................................................................................................................................................................
} //end namespace ArrayOps
