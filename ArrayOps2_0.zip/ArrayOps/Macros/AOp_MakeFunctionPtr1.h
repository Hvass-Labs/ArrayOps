//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeFunctionPtr1
//
//	Similar to MakeFunction1, only this version takes pointers to functions instead
//	of functor-classes.
//
//	In these macros, the return-type is determined by a macro-argument.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr1.h>

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

#define AOp_MakeFunctionPtr1Expr(RESTYPE, NAME, FUNPTR) \
	template <typename T, class S> \
	Expr1<RESTYPE, std::pointer_to_unary_function<T, RESTYPE>, true, Expr<T, S>, false> \
	NAME (Expr<T, S> const& x) \
	{ \
		return Expr1<	RESTYPE, \
						std::pointer_to_unary_function<T, RESTYPE>, true, \
						Expr<T, S>, false>(x, std::pointer_to_unary_function<T, RESTYPE>(FUNPTR)); \
	};

//....................................................................................................................................................................................

// Use this macro to make unary operator overloadings.

#define AOp_MakeFunctionPtr1(RESTYPE, NAME, FUNPTR) \
	AOp_MakeFunctionPtr1Expr(RESTYPE, NAME, FUNPTR);

//....................................................................................................................................................................................
} //end namespace ArrayOps
