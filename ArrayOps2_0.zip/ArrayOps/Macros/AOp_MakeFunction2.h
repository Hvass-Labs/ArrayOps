//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeFunction2
//
//	The operator overloadings used for iteratively creating new binary
//	expressions out of other sub-expressions.
//
//	In these macros, the return-type is determined by a macro-argument.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/ExprVal.h>
#include <ArrayOps/Framework/ExprVar.h>
#include <ArrayOps/Framework/Expr1.h>
#include <ArrayOps/Framework/Expr2.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

// This is the basic iterative case where both left- and right-hand operands
// are Expr<T,S> objects.
// Note that the expressions are not copied! (As indicated by all the 'false' booleans).

#define AOp_MakeFunctionExprExpr(RESTYPE, NAME, FUNCTOR) \
	template <typename T, class S1, class S2> \
	Expr2<	RESTYPE, \
			FUNCTOR##<T>, true, \
			Expr<T, S1>, false, \
			Expr<T, S2>, false> \
	NAME (Expr<T, S1> const& l, Expr<T, S2> const& r) \
	{ \
		return Expr2<	RESTYPE, \
						FUNCTOR##<T>, true, \
						Expr<T, S1>, false, \
						Expr<T, S2>, false>(l, r); \
	};

//....................................................................................................................................................................................

// These are the special cases when either the left- or right-hand operands
// are constants (e.g. the value 10.0 if T=double, or return-values from a function).

// Note that both the ExprVal-objects as well as the constant values must be copied
// (as indicated by the 'true'-booleans). This is because of C++ semantics, where the
// ExprVal-objects and the constants are destroyed upon return of these operator-functions.

#define AOp_MakeFunctionExprVal(RESTYPE, NAME, FUNCTOR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			FUNCTOR##<T>, true, \
			Expr<T, S>, false, \
			ExprVal<T>, true> \
	NAME (Expr<T, S> const& l, T const& r) \
	{ \
		return Expr2<	RESTYPE, \
						FUNCTOR##<T>, true, \
						Expr<T, S>, false, \
						ExprVal<T>, true>(l, ExprVal<T>(r)); \
	};

#define AOp_MakeFunctionValExpr(RESTYPE, NAME, FUNCTOR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			FUNCTOR##<T>, true, \
			ExprVal<T>, true, \
			Expr<T, S>, false> \
	NAME (T const& l, Expr<T, S> const& r) \
	{ \
		return Expr2<	RESTYPE, \
						FUNCTOR##<T>, true, \
						ExprVal<T>, true, \
						Expr<T, S>, false>(ExprVal<T>(l), r); \
	};

//....................................................................................................................................................................................

// These are the special cases when either the left- or right-hand operands
// are variables.

// Note that only the ExprVal-objects are copied (as indicated by the 'true'-booleans),
// and the value of the variable is assumed to be unchanged for the duration of the
// computation, and we may therefore avoid using storage for it again. However, the
// ExprVal-objects are of course still destroyed upon return of these operator-functions.

#define AOp_MakeFunctionExprVar(RESTYPE, NAME, FUNCTOR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			FUNCTOR##<T>, true, \
			Expr<T, S>, false, \
			ExprVar<T>, true> \
	NAME (Expr<T, S> const& l, T& r) \
	{ \
		return Expr2<	RESTYPE, \
						FUNCTOR##<T>, true, \
						Expr<T, S>, false, \
						ExprVar<T>, true>(l, ExprVar<T>(r)); \
	};

#define AOp_MakeFunctionVarExpr(RESTYPE, NAME, FUNCTOR) \
	template <typename T, class S> \
	Expr2<	RESTYPE, \
			FUNCTOR##<T>, true, \
			ExprVar<T>, true, \
			Expr<T, S>, false> \
	NAME (T& l, Expr<T, S> const& r) \
	{ \
		return Expr2<	RESTYPE, \
						FUNCTOR##<T>, true, \
						ExprVar<T>, true, \
						Expr<T, S>, false>(ExprVar<T>(l), r); \
	};

//....................................................................................................................................................................................

// Use this macro to make binary operator overloadings.

#define AOp_MakeFunction2(RESTYPE, NAME, FUNCTOR) \
	AOp_MakeFunctionExprExpr(RESTYPE, NAME, FUNCTOR); \
	AOp_MakeFunctionExprVar(RESTYPE, NAME, FUNCTOR); \
	AOp_MakeFunctionVarExpr(RESTYPE, NAME, FUNCTOR); \
	AOp_MakeFunctionExprVal(RESTYPE, NAME, FUNCTOR); \
	AOp_MakeFunctionValExpr(RESTYPE, NAME, FUNCTOR);

//....................................................................................................................................................................................
} //end namespace ArrayOps
