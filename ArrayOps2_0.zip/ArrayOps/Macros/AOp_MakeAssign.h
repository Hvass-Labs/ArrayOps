//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	AOp_MakeAssign
//
//	Macros for creating assignment-style functions. That is, overloadings
//	of the functions operator=, operator+=, etc. The macro is to be used
//	inside an array-class. A variant exists for the ArrayAuto-class.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/Forward.h>
#include <ArrayOps/Functions/EvalAll2.h>
#include <ArrayOps/Tools/Functional.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The macro parameters are as follows:

	// ARRAY is the name of the array-class, e.g. Array.
	// OPNAME is the name of the operator, e.g. operator=.
	// FUNCTOR is the name of the functor, e.g. assign.

//....................................................................................................................................................................................

// Assignment from same class.

#define AOp_MakeAssignSame(ARRAY, OPNAME, FUNCTOR) \
	ARRAY & \
	OPNAME (ARRAY const& x) \
	{ \
		EvalAll<FUNCTOR##<T> >(*this, x); \
		return *this; \
	};

//....................................................................................................................................................................................

// Assignment from an Expr-object.

#define AOp_MakeAssignExpr(ARRAY, OPNAME, FUNCTOR) \
	template <class S1> \
	ARRAY & \
	OPNAME (Expr<T, S1> const& x) \
	{ \
		EvalAll<FUNCTOR##<T> >(*this, x); \
		return *this; \
	};

//....................................................................................................................................................................................

// Assignment from a value or variable. Note the value is used immediately,
// and there is hence no need for copying it if it was a constant value.

#define AOp_MakeAssignVal(ARRAY, OPNAME, FUNCTOR) \
	ARRAY & \
	OPNAME (T const& x) \
	{ \
		EvalAll<FUNCTOR##<T> >(*this, x); \
		return *this; \
	};

//....................................................................................................................................................................................

// This macro is for accumulative operators, such as +=, *=, etc.
#define AOp_MakeAccumulate(ARRAY, OPNAME, FUNCTOR) \
	AOp_MakeAssignExpr(ARRAY, OPNAME, FUNCTOR); \
	AOp_MakeAssignVal(ARRAY, OPNAME, FUNCTOR);

// This macro is for overwriting operators, such as assignment via =.
#define AOp_MakeOverwrite(ARRAY, OPNAME, FUNCTOR) \
	AOp_MakeAssignSame(ARRAY, OPNAME, FUNCTOR); \
	AOp_MakeAssignExpr(ARRAY, OPNAME, FUNCTOR); \
	AOp_MakeAssignVal(ARRAY, OPNAME, FUNCTOR);

//....................................................................................................................................................................................

// Use this macro to make assignment operator overloadings inside a class.

#define AOp_MakeAssign(ARRAY) \
	AOp_MakeOverwrite(ARRAY, operator=,    assign); \
	AOp_MakeAccumulate(ARRAY, operator+=,  assign_plus); \
	AOp_MakeAccumulate(ARRAY, operator-=,  assign_minus); \
	AOp_MakeAccumulate(ARRAY, operator*=,  assign_multiplies); \
	AOp_MakeAccumulate(ARRAY, operator/=,  assign_divides); \
	AOp_MakeAccumulate(ARRAY, operator%=,  assign_modulus); \
	AOp_MakeAccumulate(ARRAY, operator&=,  assign_bitwise_and); \
	AOp_MakeAccumulate(ARRAY, operator|=,  assign_bitwise_or); \
	AOp_MakeAccumulate(ARRAY, operator^=,  assign_bitwise_xor); \
	AOp_MakeAccumulate(ARRAY, operator<<=, assign_bitwise_lshift); \
	AOp_MakeAccumulate(ARRAY, operator>>=, assign_bitwise_rshift);

//....................................................................................................................................................................................
} //end namespace ArrayOps
