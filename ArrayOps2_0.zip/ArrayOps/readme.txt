ArrayOps - Vector Computation Library For C++.
Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
Published under the GNU Lesser General Public License.
Please see the file license.txt for license details.
ArrayOps on the internet: http://www.Hvass-Labs.org/


Installation:

Installing and using ArrayOps is incredibly simple, as there
are no code-libraries that have to be compiled, and ArrayOps
only consists of C++ header-files. Simply do the following:

1) Go to http://www.Hvass-Labs.org/ArrayOps/ and follow the
   download instructions.
2) Unpack the ArrayOps source-code to a directory of your choice.
3) Add that directory to the include-paths of your C++ project.
4) Add #include statements to your source-code, for the ArrayOps
   datatypes that you need (e.g. Array, ArrayMini, or ArrayUse).
   Write your source-code using ArrayOps, and compile.


Compiler Compatibility:

ArrayOps was developed in MS Visual C++ 2005, and as the
source-code relies on fairly new programming techniques, it may
not be compatible with all C++ compilers. 


Warning:

Although the current version of ArrayOps is considered fully
functional, the library is still in development, and
particularly the more exotic features as well as the internal
framework, may change in future versions.



Update History:

Version 2.0:
- All expressions must now implement IsSized() and Size() queries
  in both debug- and release-mode. This means the Expr1 and Expr2
  implementations have been changed. Now the calls traverse the
  entire expression-tree, but this should be optimized during
  compile-time by the compiler to a single call to one of the
  leafs in the expression-tree, because such a leaf may be
  determined at compile-time due to const-ness of an expression's
  sub-expressions.
- The const-version of checked lookup through the at() function,
  has been moved to the Expr-class, because Expr is now assumed to
  always implement the size queries, regardless of compilation mode,
  and these are needed by the at() functions.
- Changed Expr, Expr1, Expr2, ExprVarVal, and Storage classes to
  pass implementor-object through constructor. This means we can now
  use C++ references instead of pointers in the Storage-class, and
  the framework's source-code is generally made simpler.
- Added the function ResizeCopy() to the Array-class.
- Implemented ArrayAuto class which automatically resizes according
  to size of right-hand in an assignment. In accumulative assignments
  (such as +=, *=, etc.), the contents of the array are first copied,
  and in overwriting assignments, they are not.
- Removed ExprOp1 and ExprOp2 and made Expr1 and Expr2 support these
  special cases through a template parameter passed to the instance
  of the Storage-class for the operator.
- Fixed bug in macros for generation of various kinds of expressions.
  Argument expressions were non-const and should of course be const
  to ensure that there are no side-effects.
- Changed all class-destructors for ArrayBase and its derivations,
  from virtual to non-virtual. This makes compiler optimizations
  easier. Furthermore, this uncovered a bug in the test-program when
  storing nested objects of Slice(), Cycle(), and Reverse() arrays.
  It is not really a bug in ArrayOps, but it allows such erroneous
  usage, which is of course unfortunate.
- Simplified ArraySlice, ArrayCycle, and ArrayReverse.
- Declared variables in ArraySlice_Imp and ArrayCycle_Imp classes for
  const. This might aid the compiler in making optimizations.
- Added the functions: pow2, pow4, and pow8, for computing the
  respective powers.
- Added a set of functions named ReduceAll, for making reductions
  by the use of functors. The ReduceAll functions will return a
  value (e.g. an integer), and can be used for e.g. summation of
  an array's elements.
- Added Sum, Product, Norm, Mean, and Variance functions that use the
  ReduceAll functions.
- Changed EvalAll-functions to have const operator functors. This
  disallows side-effects, and means the functor objects could be removed
  from the OpenMP private() statements as well.

Version 1.0:
- First release.
