//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ArrayCycle_Imp
//
//	The base-class for the ArrayCycle-class from ArrayBase.
//	It provides a cyclic array, where you may index from zero
//	up to infinity (within the boundaries of an unsigned int
//	of course).
//
//	It essentially just maps from A[i] to A[(i+offset)%A.Size()],
//	note that it is only implemented for ArrayBase, which is
//	always assumed to have a welldefined size.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/Forward.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The implementor-class containing storage and basic functions.
	template <class T, class S, bool Parallel>
	class ArrayCycle_Imp
	{
	public:
		ArrayCycle_Imp				(ArrayBase<T,S,Parallel>& arr, unsigned int offset) : mArray(arr), mOffset(offset) {}

		// Element lookup.
		inline T&		operator[]	(unsigned int i)
		{
			return mArray[(i+mOffset) % Size()];
		}

		// Element lookup, const.
		inline
		T const&		operator[]	(unsigned int i) const
		{
			return mArray[(i+mOffset) % Size()];
		}

		// Size of array.
		inline
		unsigned int	Size		() const { return mArray.Size(); }
		inline bool		IsSized		() const { return true; }

	protected:
		ArrayBase<T,S,Parallel>&		mArray;
		const unsigned int				mOffset;
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
