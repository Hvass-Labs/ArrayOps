//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ArrayReverse_Imp
//
//	The base-class for the ArrayReverse-class from ArrayBase.
//	It provides a reversed array, where you may index its
//	elements in reverse order.
//
//	It essentially just maps from A[i] to A[A.Size()-i-1],
//	note that it is only implemented for ArrayBase, which is
//	always assumed to have a welldefined size.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/Forward.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The implementor-class containing storage and basic functions.
	template <class T, class S, bool Parallel>
	class	ArrayReverse_Imp
	{
	public:
		ArrayReverse_Imp			(ArrayBase<T,S,Parallel>& arr) : mArray(arr) {}

		// Element lookup.
		inline T&		operator[]	(unsigned int i)
		{
			return mArray[Size()-i-1];
		}

		// Element lookup, const.
		inline
		T const&		operator[]	(unsigned int i) const
		{
			return mArray[Size()-i-1];
		}

		// Size of array.
		inline
		unsigned int	Size		() const { return mArray.Size(); }
		inline bool		IsSized		() const { return true; }

	protected:
		ArrayBase<T,S,Parallel>&		mArray;
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
