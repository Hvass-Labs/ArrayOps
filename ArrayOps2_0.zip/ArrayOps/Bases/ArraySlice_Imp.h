//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ArraySlice_Imp
//
//	The base-class for the ArraySlice-class from ArrayBase.
//	It provides a slice of an array, that is, a new array
//	that references the original, but with an offset index,
//	and a possibly new (and appropriate) size. The size
//	however, is only enforced in debug-mode.
//
//	It essentially just maps from A[i] to A[i+offset].
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/Forward.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The implementor-class containing storage and basic functions.
	template <class T, class S, bool Parallel>
	class	ArraySlice_Imp
	{
	public:
		ArraySlice_Imp				(ArrayBase<T,S,Parallel>& arr, unsigned int offset, unsigned int size) : mArray(arr), kOffset(offset), kSize(size) {}

		// Element lookup.
		inline T&		operator[]	(unsigned int i)
		{
			assert(i<kSize);

			return mArray[i+kOffset];
		}

		// Element lookup, const.
		inline
		T const&		operator[]	(unsigned int i) const
		{
			assert(i<kSize);

			return mArray[i+kOffset];
		}

		// Size of array.
		inline
		unsigned int	Size		() const { return kSize; }
		inline bool		IsSized		() const { return true; }

	protected:
		ArrayBase<T,S,Parallel>&		mArray;
		const unsigned int				kOffset;
		const unsigned int				kSize;
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
