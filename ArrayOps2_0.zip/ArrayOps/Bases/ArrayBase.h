//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ArrayBase
//
//	The base-class that all Array-classes must derive from.
//	Also includes various index-manipulation wrapper-classes,
//	for producing slices, cycles, and reverse-iterated arrays
//	(which are themselves sub-classes of ArrayBase).
//
//	An instance of ArrayBase is always assumed to have IsSized()
//	return true, and hence Size() is welldefined. Note that IsSized()
//	can not be implemented in ArrayBase, because of the specific
//	kind of usage of socalled 'reverse inheritance'.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr.h>
#include <ArrayOps/Creators/Meta.h>
#include <ArrayOps/Bases/ArraySlice_Imp.h>
#include <ArrayOps/Bases/ArrayCycle_Imp.h>
#include <ArrayOps/Bases/ArrayReverse_Imp.h>
#include <ArrayOps/Macros/AOp_MakeAssign.h>

#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The default parallelism limit.
	const unsigned int kParLimit = 1000;
	
//....................................................................................................................................................................................

	// The ArrayBase-class that all Array-classes must derive from.
	template <class T, class S, bool Parallel>
	class ArrayBase : public Expr<T, S>
	{
	public:
		ArrayBase							(unsigned int parLimit=kParLimit) : Expr<T, S>(), mParLimit(parLimit) {}
		ArrayBase							(S const& s, unsigned int parLimit=kParLimit) : Expr<T, S>(s), mParLimit(parLimit) {}

		// Element lookup, non-const.
		T& at(unsigned int i)
		{
			if (i >= S::Size())
			{
				throw std::out_of_range(kErrRange);
			}

			return (*this)[i];
		}

		// Get/Set the limits for when to use parallelism.
		inline int				GetParLimit	() const { return mParLimit; }
		inline void				SetParLimit	(int parLimit) { mParLimit = parLimit; }

		// Forward declarations for different index-manipulation arrays.
		class ArraySlice;
		class ArrayCycle;
		class ArrayReverse;

		// Return an ArraySlice-object of the given ArrayBase-instance.
		inline ArraySlice		Slice		(unsigned int offset, unsigned int size)
		{
			return ArraySlice(*this, offset, size);
		}

		// Return an ArrayCycle-object of the given ArrayBase-instance.
		inline ArrayCycle		Cycle		(const unsigned int offset=0)
		{
			return ArrayCycle(*this, offset);
		}

		// Return an ArrayReverse-object of the given ArrayBase-instance.
		inline ArrayReverse		Reverse		()
		{
			return ArrayReverse(*this);
		}

	private:
		// Ensure no implicit assignments (and allocations) take place.
		ArrayBase					(ArrayBase const& arr) { assert(false); }

		// Ensure no unhandled assignment takes place.
		template <class X>
		ArrayBase& operator=		(X const& x) { assert(false); }

		// Ensure no unhandled assignment takes place.
		template <class X>
		ArrayBase& operator=		(X& x) { assert(false); }

		int	mParLimit;
	};

//....................................................................................................................................................................................

	// The ArraySlice-class, which is really just an index-manipulation wrapper-class.
	template <class T, class S, bool Parallel>
	class ArrayBase<T,S,Parallel>::ArraySlice : public ArrayBase<T, ArraySlice_Imp<T,S,Parallel>, Parallel>
	{
	public:
		// Convenient type-definition of implementor.
		typedef ArraySlice_Imp<T, S, Parallel> TImp;

		ArraySlice(ArrayBase& arr, unsigned int offset, unsigned int size) : ArrayBase<T, TImp, Parallel>(TImp(arr, offset, size)) { }

		// Macro that makes overloadings for the assignment operators.
		AOp_MakeAssign(ArraySlice);
	};

//....................................................................................................................................................................................

	// The ArrayCycle-class, which is really just an index-manipulation wrapper-class.
	template <class T, class S, bool Parallel>
	class ArrayBase<T,S,Parallel>::ArrayCycle : public ArrayBase<T, ArrayCycle_Imp<T,S,Parallel>, Parallel>
	{
	public:
		// Convenient type-definition of implementor.
		typedef ArrayCycle_Imp<T, S, Parallel> TImp;

		ArrayCycle(ArrayBase& arr, unsigned int offset) : ArrayBase<T, TImp, Parallel>(TImp(arr, offset)) { }

		// Macro that makes overloadings for the assignment operators.
		AOp_MakeAssign(ArrayCycle);
	};

//....................................................................................................................................................................................

	// The ArrayReverse-class, which is really just an index-manipulation wrapper-class.
	template <class T, class S, bool Parallel>
	class ArrayBase<T,S,Parallel>::ArrayReverse : public ArrayBase<T, ArrayReverse_Imp<T,S,Parallel>, Parallel>
	{
	public:
		// Convenient type-definition of implementor.
		typedef ArrayReverse_Imp<T, S, Parallel> TImp;

		ArrayReverse(ArrayBase& arr) : ArrayBase<T, TImp, Parallel>(TImp(arr)) { }

		// Macro that makes overloadings for the assignment operators.
		AOp_MakeAssign(ArrayReverse);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
