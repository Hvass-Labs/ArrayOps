//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Math
//
//	Creates the basic mathematical functions for taking arrays as arguments.
//
//	Note a few special functions are not implemented in this version,
//	such as the div() function from the <cstdlib> header-file.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Macros/AOp_MakeOperatorPtr1.h>
#include <ArrayOps/Macros/AOp_MakeOperatorPtr2.h>

#include <cmath>
#include <cstdlib>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Mathematical functions

	AOp_MakeOperatorPtr1(abs,	&std::abs);
	AOp_MakeOperatorPtr1(fabs,	&std::fabs);

	AOp_MakeOperatorPtr1(ceil,	&std::ceil);
	AOp_MakeOperatorPtr1(floor,	&std::floor);

	AOp_MakeOperatorPtr1(sqrt,	&std::sqrt);

	AOp_MakeOperatorPtr2(pow,	&std::pow);

	AOp_MakeOperatorPtr1(cos,	&std::cos);
	AOp_MakeOperatorPtr1(sin,	&std::sin);
	AOp_MakeOperatorPtr1(tan,	&std::tan);

	AOp_MakeOperatorPtr1(acos,	&std::acos);
	AOp_MakeOperatorPtr1(asin,	&std::asin);
	AOp_MakeOperatorPtr1(atan,	&std::atan);
	AOp_MakeOperatorPtr2(atan2,	&std::atan2);

	AOp_MakeOperatorPtr1(cosh,	&std::cosh);
	AOp_MakeOperatorPtr1(sinh,	&std::sinh);
	AOp_MakeOperatorPtr1(tanh,	&std::tanh);

	AOp_MakeOperatorPtr1(exp,	&std::exp);
	AOp_MakeOperatorPtr1(log,	&std::log);
	AOp_MakeOperatorPtr1(log10,	&std::log10);

	AOp_MakeOperatorPtr2(fmod,	&std::fmod);

//....................................................................................................................................................................................
} //end namespace ArrayOps
