//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Meta
//
//	This file is included by all the different Array-header-files,
//	and is basically a list of includes of all the relevant operator-
//	overloadings, mathematical functions, etc.
//
//	It also defines the ARRAYOPS variable, so you may use an #ifdef-clause
//	to see if ArrayOps is available.
//
//....................................................................................................................................................................................

#pragma once

// You may use #ifdef to see if ArrayOps is available.
#define ARRAYOPS

// ArrayOps Version #defines
#include <ArrayOps/Tools/Version.h>

// Basic operator overloadings.
#include <ArrayOps/Creators/Operator.h>

// Casting functions.
#include <ArrayOps/Creators/Cast.h>

// Mathematical functions.
#include <ArrayOps/Creators/Math.h>
#include <ArrayOps/Creators/Power.h>

// Evaluation helper-functions.
#include <ArrayOps/Functions/Eval1.h>

// Reduction functions.
#include <ArrayOps/Functions/ReduceAll.h>

// Summation etc. functions.
#include <ArrayOps/Functions/Sum.h>
#include <ArrayOps/Functions/Product.h>
#include <ArrayOps/Functions/Norm.h>
#include <ArrayOps/Functions/Mean.h>
#include <ArrayOps/Functions/Variance.h>
#include <ArrayOps/Functions/Reduce.h>
