//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Cast
//
//	Creates the different kinds of basic casting-functions, for casting
//	individual array-elements.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Macros/AOp_MakeCast.h>
#include <ArrayOps/Tools/Functional.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	AOp_MakeCast(StaticCast, static_caster);
	AOp_MakeCast(DynamicCast, dynamic_caster);
	AOp_MakeCast(ConstCast, const_caster);
	AOp_MakeCast(ReinterpretCast, reinterpret_caster);

//....................................................................................................................................................................................
} //end namespace ArrayOps
