//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Power
//
//	Creates various power-functions that take arrays as arguments.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Macros/AOp_MakeOperator1.h>
#include <ArrayOps/Tools/Functional.h>

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

	AOp_MakeOperator1(pow2, power2);
	AOp_MakeOperator1(pow4, power4);
	AOp_MakeOperator1(pow8, power8);

//....................................................................................................................................................................................
} //end namespace ArrayOps
