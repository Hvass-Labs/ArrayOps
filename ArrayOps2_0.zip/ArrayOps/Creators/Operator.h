//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Operator
//
//	The operator overloadings used for iteratively creating new expressions out of others.
//	These are generated simply by expanding the MakeOperator()-macros with proper arguments.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/Functional.h>
#include <ArrayOps/Macros/AOp_MakeOperator1.h>
#include <ArrayOps/Macros/AOp_MakeOperator2.h>
#include <ArrayOps/Macros/AOp_MakeOperatorLogical1.h>
#include <ArrayOps/Macros/AOp_MakeOperatorLogical2.h>

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

// Binary operator-overloadings.

AOp_MakeOperator2(operator+, std::plus);
AOp_MakeOperator2(operator-, std::minus);
AOp_MakeOperator2(operator*, std::multiplies);
AOp_MakeOperator2(operator/, std::divides);
AOp_MakeOperator2(operator%, std::modulus);

//....................................................................................................................................................................................

// Binary operator-overloadings, bitwise operators.

AOp_MakeOperator2(operator<<, bitwise_leftshift);
AOp_MakeOperator2(operator>>, bitwise_rightshift);
AOp_MakeOperator2(operator&,  bitwise_and);
AOp_MakeOperator2(operator|,  bitwise_inclusive_or);
AOp_MakeOperator2(operator^,  bitwise_exclusive_or);

//....................................................................................................................................................................................

// Binary operator-overloadings, logical operators (comparison).

AOp_MakeOperatorLogical2(operator==, std::equal_to);
AOp_MakeOperatorLogical2(operator!=, std::not_equal_to);
AOp_MakeOperatorLogical2(operator>,  std::greater);
AOp_MakeOperatorLogical2(operator<,  std::less);
AOp_MakeOperatorLogical2(operator>=, std::greater_equal);
AOp_MakeOperatorLogical2(operator<=, std::less_equal);
AOp_MakeOperatorLogical2(operator&&, std::logical_and);
AOp_MakeOperatorLogical2(operator||, std::logical_or);

//....................................................................................................................................................................................

// Unary operator-overloadings.

AOp_MakeOperator1(operator-, std::negate);

//....................................................................................................................................................................................

// Unary operator-overloadings, logical operators (comparison).

AOp_MakeOperatorLogical1(operator!, std::logical_not);

//....................................................................................................................................................................................
} //end namespace ArrayOps
