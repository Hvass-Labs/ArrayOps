//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ArrayUse
//
//	Data-structure that re-uses an array, e.g. supplied by the
//	operating system. By default, parallellism is turned on.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Bases/ArrayBase.h>
#include <ArrayOps/Macros/AOp_MakeAssign.h>
#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The base-class containing storage and basic functions.
	template <class T>
	class	ArrayUse_Imp
	{
	public:
		ArrayUse_Imp				() : mStorage(0), mSize(0) {}

		// Element lookup.
		inline T&		operator[]	(unsigned int i)
		{
			assert(i<mSize);
			assert(mStorage);

			return mStorage[i];
		}

		// Element lookup, const.
		inline
			T const&		operator[]	(unsigned int i) const
		{
			assert(i<mSize);
			assert(mStorage);

			return mStorage[i];
		}

		// Size of array.
		inline
		unsigned int	Size		() const { return mSize; }
		inline bool		IsSized		() const { return true; }

	protected:
		// Sets a pointer to the array-storage and the size.
		void			Set			(T* storage, unsigned int size)
		{
			mStorage = storage;
			mSize = size;
		}

	protected:
		T*					mStorage;
		unsigned int		mSize;
	};

//....................................................................................................................................................................................

	// The actual ArrayUse-class that you should instantiate.
	template <class T, bool Parallel=true>
	class ArrayUse : public ArrayBase<T, ArrayUse_Imp<T>, Parallel>
	{
	public:
		ArrayUse (T* storage, unsigned int size) : ArrayBase<T, ArrayUse_Imp<T>, Parallel>()
		{
			Set(storage, size);
		}

		// Macro that makes overloadings for the assignment operators.
		AOp_MakeAssign(ArrayUse);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
