//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Storage
//
//	A template class for storage of expressions and values, used in the
//	meta-programming classes Expr1, Expr2, and so on.
//
//	The template-argument X designates the datatype for the object to be stored,
//	and the Copy-argument designates whether or not that object should be copied,
//	or if we should actually only store a pointer to it.
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The template-class defintion (which is empty).
	template <class X, bool Copy>
	class Storage
	{
	};

//....................................................................................................................................................................................

	// The specialization for storing just a reference to the element.
	template <class X>
	class Storage<X, false>
	{
	public:
		Storage(X const& x) : mX(x) {}

		inline X const& Get() const { return mX; }

	protected:
		X const& mX;
	};

//....................................................................................................................................................................................
	
	// The specialization for storing a copy (i.e. instance) of the element.
	template <class X>
	class Storage<X, true>
	{
	public:
		Storage() : mX() {}
		Storage(X const& x) : mX(x) {}

		inline X const& Get() const { return mX; }

	protected:
		X mX;
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
