//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Expr2
//
//	Specialization of the Expr-class for binary expressions.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr.h>
#include <ArrayOps/Framework/Storage.h>
#include <ArrayOps/Tools/MatchingSize.h>

#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The implementor class for a binary expression.
	template <typename T, class Op, bool CopyOp, class L, bool CopyL, class R, bool CopyR>
	class Expr2_Imp
	{
	public:
		Expr2_Imp(L const& l, R const& r) : mOp(), mL(l), mR(r) {}
		Expr2_Imp(L const& l, R const& r, Op const& op) : mOp(op), mL(l), mR(r) {}

		inline T operator[] (unsigned int index) const
		{
			// Get the operator functor.
			Op const& op = mOp.Get();

			// Apply operator and return result.
			return op(mL.Get()[index], mR.Get()[index]);
		};

		inline bool		IsSized		() const { return (mL.Get().IsSized() || mR.Get().IsSized()); }
		inline
		unsigned int	Size		() const { return (mL.Get().IsSized()) ? (mL.Get().Size()) : (mR.Get().Size()); }

	protected:
		Storage<Op, CopyOp>	mOp;		// The operator functor.
		Storage<L, CopyL>	mL;			// Left operand (sub-expression).
		Storage<R, CopyR>	mR;			// Right operand (sub-expression).
	};

//....................................................................................................................................................................................

	// The instantiator class for a binary expression.
	// This is the class that you should instantiate.
	template <typename T, class Op, bool CopyOp, class L, bool CopyL, class R, bool CopyR>
	class Expr2 : public Expr<T, Expr2_Imp<T, Op, CopyOp, L, CopyL, R, CopyR> >
	{
	public:
		// Convenient type-definition of implementor.
		typedef Expr2_Imp<T, Op, CopyOp, L, CopyL, R, CopyR> TImp;

		Expr2(L const& l, R const& r) : Expr<T, TImp>(TImp(l, r))
		{
			assert(MatchingSize(mL.Get(), mR.Get()));
		}

		Expr2(L const& l, R const& r, Op const& op) : Expr<T, TImp>(TImp(l, r, op))
		{
			assert(MatchingSize(mL.Get(), mR.Get()));
		}
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
