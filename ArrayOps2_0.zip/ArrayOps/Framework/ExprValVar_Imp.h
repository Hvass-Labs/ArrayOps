//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ExprValVar_Imp
//
//	The base-class containing storage and basic functions for either
//	storing a reference to a variable, or a copy of a constant value.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Storage.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The implementor class for a value/variable-expression.
	template <typename T, bool Copy>
	class ExprValVar_Imp
	{
	public:
		ExprValVar_Imp(T const& value) : mValue(value) {}

		inline T const& operator[] (unsigned int index) const
		{
			return mValue.Get();
		};

		inline
		unsigned int	Size		() const { return 0; }
		inline bool		IsSized		() const { return false; }

	protected:
		Storage<T, Copy>	mValue;		// The value.
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
