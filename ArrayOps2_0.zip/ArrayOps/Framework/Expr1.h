//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Expr1
//
//	Specialization of the Expr-class for unary expressions.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr.h>
#include <ArrayOps/Framework/Storage.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The implementor class for a unary expression.
	template <typename T, class Op, bool CopyOp, class X, bool CopyX>
	class Expr1_Imp
	{
	public:
		Expr1_Imp(X const& x) : mOp(), mX(x) {}
		Expr1_Imp(X const& x, Op const& op) : mOp(op), mX(x) {}

		inline T operator[] (unsigned int index) const
		{
			// Get the operator functor.
			Op const& op = mOp.Get();

			// Apply operator and return result.
			return op(mX.Get()[index]);
		};

		inline bool		IsSized		() const { return mX.Get().IsSized(); }
		inline
		unsigned int	Size		() const { return mX.Get().Size(); }

	protected:
		Storage<Op, CopyOp>	mOp;		// The operator functor.
		Storage<X, CopyX>	mX;			// Operand sub-expression.
	};

//....................................................................................................................................................................................

	// The instantiator class for a unary expression.
	// This is the class that you should instantiate.
	template <typename T, class Op, bool CopyOp, class X, bool CopyX>
	class Expr1 : public Expr<T, Expr1_Imp<T, Op, CopyOp, X, CopyX> >
	{
	public:
		// Convenient type-definition of implementor.
		typedef Expr1_Imp<T, Op, CopyOp, X, CopyX> TImp;

		Expr1(X const& x) : Expr<T, TImp>(TImp(x)) { }

		Expr1(X const& x, Op const& op) : Expr<T, TImp>(TImp(x, op)) { }
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
