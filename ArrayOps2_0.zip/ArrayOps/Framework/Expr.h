//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Expr
//
//	The Expr-class is the base-class for all expressions involved
//	in array computations. It is expected that all derivations
//	of the Expr-class, provide the operator[] lookup functions,
//	a function IsSized() returning a boolean, designating whether
//	or not the expression is sized (for example, an array is of
//	course sized, whereas a nullary function or a constant value
//	is not). Furthermore a function Size() must be provided, that
//	returns the size of the array, provided the expression is sized.
//	Otherwise, the result of Size() is undefined.
//
//....................................................................................................................................................................................

#pragma once

#include <stdexcept>

namespace ArrayOps
{
//....................................................................................................................................................................................

	const std::string kErrRange("Index out of range.");

//....................................................................................................................................................................................

	// The Expr-class.
	template <typename T, class S>
	class Expr : public S
	{
	public:
		Expr () : S() {}
		Expr (S const& s) : S(s) {}

		// Element lookup, const.
		T const& at(unsigned int i) const
		{
			if (i >= S::Size())
			{
				throw std::out_of_range(kErrRange);
			}

			return (*this)[i];
		}
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
