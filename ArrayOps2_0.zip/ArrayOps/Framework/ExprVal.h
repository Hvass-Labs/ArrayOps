//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ExprVal
//
//	An expression storing a copy of a value. This is needed
//	when a constant value appears in an expression, as the
//	value is lost before it must be used, when meta-programming
//	is applied.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr.h>
#include <ArrayOps/Framework/ExprValVar_Imp.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The instantiator class for a value-expression.
	// This is the class that you should instantiate.
	template <typename T>
	class ExprVal : public Expr<T, ExprValVar_Imp<T, true> >
	{
	public:
		// Convenient type-definition of implementor.
		typedef ExprValVar_Imp<T, true> TImp;

		ExprVal(T const& value) : Expr<T, TImp>(TImp(value)) {}
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
