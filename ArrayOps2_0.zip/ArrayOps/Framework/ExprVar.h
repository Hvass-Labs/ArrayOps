//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ExprVar
//
//	An expression storing a reference to a variable.
//	That is, the contents of that variable are not copied.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Framework/Expr.h>
#include <ArrayOps/Framework/ExprValVar_Imp.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The instantiator class for a variable-expression.
	// This is the class that you should instantiate.
	template <typename T>
	class ExprVar : public Expr<T, ExprValVar_Imp<T, false> >
	{
	public:
		// Convenient type-definition of implementor.
		typedef ExprValVar_Imp<T, false> TImp;

		ExprVar(T const& value) : Expr<T, TImp>(TImp(value)) {}
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
