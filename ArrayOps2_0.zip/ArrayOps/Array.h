//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Array
//
//	Data-structure for a basic resizable array. By default,
//	parallellism is turned on.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Bases/ArrayBase.h>
#include <ArrayOps/Macros/AOp_MakeAssign.h>
#include <ArrayOps/ArrayUse.h>
#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The base-class containing storage and basic functions.
	template <class T>
	class Array_Imp
	{
	public:
		Array_Imp					() : mStorage(0), mSize(0) {}
		~Array_Imp					() { DoDelete(); }

		// Element lookup.
		inline T&		operator[]	(unsigned int i)
		{
			assert(i<mSize);
			assert(mStorage);

			return mStorage[i];
		}

		// Element lookup, const.
		inline
		T const&		operator[]	(unsigned int i) const
		{
			assert(i<mSize);
			assert(mStorage);

			return mStorage[i];
		}

		// Size of array.
		inline
		unsigned int	Size		() const { return mSize; }
		inline bool		IsSized		() const { return true; }

	protected:
		void		DoAllocate		(unsigned int size)
		{
			// Assert the old storage has been deleted by DoDelete().
			assert(mStorage == 0);

			mStorage = new T[size];
			mSize = size;
		}

		// This may be called even when storage has not been allocated.
		void		DoDelete		()
		{
			delete [] mStorage;
			mStorage = 0;
			mSize = 0;
		}

	protected:
		T*					mStorage;
		unsigned int		mSize;
	};

//....................................................................................................................................................................................

	// The actual Array-class that you should instantiate.
	template <class T, bool Parallel=true>
	class Array : public ArrayBase<T, Array_Imp<T>, Parallel>
	{
	public:
		Array () : ArrayBase<T, Array_Imp<T>, Parallel>() { }
		Array (unsigned int size) : ArrayBase<T, Array_Imp<T>, Parallel>()
		{
			DoAllocate(size);
		}

		// Resize the array, by first deleting existing storage,
		// then allocate new. The new storage is uninitialized.
		void	Resize			(unsigned int size)
		{
			DoDelete();
			DoAllocate(size);
		}

		// Resize the array, by first allocating new storage,
		// then copying data from the old. The remainder of the
		// elements are uninitialized. The new size is not required
		// to differ from the old size.
		void	ResizeCopy		(unsigned int newSize)
		{
			unsigned int oldSize = Size();

			if (oldSize == 0)
			{
				// If the size is zero, it may still mean
				// that storage of length zero has been allocated,
				// so we must ensure that it is deleted first.

				Resize(newSize);
			}
			else
			{
				// Allocate the new storage.
				T* newStorage = new T[newSize];

				// Wrap the new storage in ArrayUse.
				ArrayUse<T,Parallel> newArray(newStorage, newSize);

				// Copy elements from old storage.
				if (newSize>oldSize)
				{
					newArray.Slice(0, oldSize) = *this;
				}
				else
				{
					// New array is smaller than the old one.
					newArray = (*this).Slice(0, newSize);
				}

				DoDelete();

				mSize = newSize;
				mStorage = newStorage;
			}
		}

		// Macro that makes overloadings for the assignment operators.
		AOp_MakeAssign(Array);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
