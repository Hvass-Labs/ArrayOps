//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	MatchingSize
//
//	Functions for checking whether Expr-objects have matching size.
//	They assume the Expr-objects have two functions: IsSized() and
//	Size().
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Tools/Forward.h>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// Return whether two expressions are of matching size.
	template <class T, class S1, class S2>
	inline
	bool MatchingSize(	Expr<T, S1> const& a,
						Expr<T, S2> const& b)
	{
		return !(a.IsSized() && b.IsSized()) || a.Size() == b.Size();
	}
	
//....................................................................................................................................................................................

	// Return whether three expressions are of matching size.
	template <class T, class S1, class S2, class S3>
	inline
	bool MatchingSize(	Expr<T, S1> const& a,
						Expr<T, S2> const& b,
						Expr<T, S3> const& c)
	{
		return MatchingSize(a, b) && MatchingSize(a, c) && MatchingSize(b, c);
	}

//....................................................................................................................................................................................
} //end namespace ArrayOps
