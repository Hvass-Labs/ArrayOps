//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Forward
//
//	Forward declarations to avoid cyclic dependencies.
//
//....................................................................................................................................................................................

#pragma once

namespace ArrayOps
{
//....................................................................................................................................................................................

	template <class T, class S, bool Parallel> class ArrayBase;
	template <class T, bool Parallel> class Array;
	template <class T, bool Parallel> class ArrayUse;
	template <class T, bool Parallel> class ArrayAuto;
	template <class T, unsigned int kSize, bool Parallel> class ArrayMini;

//....................................................................................................................................................................................
} //end namespace ArrayOps
