//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Accumulator
//
//	A functor class for accumulation. This may be used in
//	e.g. summation where the Accumulator-functor is then
//	supplied with a binary functor providing an operator
//	such as +=. Note that you must supply the constructor
//	of the Accumulator-class with the initial value. For
//	summation this would be zero, and for computing the
//	product the initial value would be one.
//
//....................................................................................................................................................................................

#pragma once

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

	template <typename T, class F>
	class Accumulator : public std::unary_function<T,T>
	{
	public:
		Accumulator(T const& init) : std::unary_function<T,T>(), mFunctor(), mAcc(init) {}

		inline T const& operator() (T const& x)
		{
			mFunctor(mAcc, x);
			return mAcc;
		}

		inline T const& operator() ()
		{
			return mAcc;
		}

	protected:
		const F		mFunctor;
		T			mAcc;
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
