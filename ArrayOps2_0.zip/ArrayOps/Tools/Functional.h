//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Functional
//
//	Extensions to the standard <functional> header-file.
//
//....................................................................................................................................................................................

#pragma once

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// A definition similar to std::unary_function and std::binary_function,
	// only for functions taking no arguments.
	template<class TRes>
	struct nullary_function
	{
		typedef TRes result_type;
	};

//....................................................................................................................................................................................

	// Similar to pointer_to_unary_function, only for nullary functions.
	template<class TRes, class TFunPtr = TRes (*)()>
	class pointer_to_nullary_function : public nullary_function<TRes>
	{
	public:
		explicit pointer_to_nullary_function(TFunPtr funPtr) : mFunPtr(funPtr) {}

		inline
		TRes operator()() const { return mFunPtr(); }

	protected:
		TFunPtr mFunPtr;	// the function pointer
	};

//....................................................................................................................................................................................

	// Functor-classes for the different casting functions.

	// Static casting.
	template <typename TRes, typename TArg>
	struct static_caster : public std::unary_function<TRes, TArg>
	{
		TRes operator()(TArg const& x) const
		{
			return static_cast<TRes>(x);
		}
	};

	// Dynamic casting.
	template <typename TRes, typename TArg>
	struct dynamic_caster : public std::unary_function<TRes, TArg>
	{
		TRes operator()(TArg const& x) const
		{
			return dynamic_cast<TRes>(x);
		}
	};

	// Const casting.
	template <typename TRes, typename TArg>
	struct const_caster : public std::unary_function<TRes, TArg>
	{
		TRes operator()(TArg const& x) const
		{
			return const_cast<TRes>(x);
		}
	};

	// Reinterpret casting.
	template <typename TRes, typename TArg>
	struct reinterpret_caster : public std::unary_function<TRes, TArg>
	{
		TRes operator()(TArg const& x) const
		{
			return reinterpret_cast<TRes>(x);
		}
	};

//....................................................................................................................................................................................

	// Functor-classes for bitwise binary operators.

	// Bitwise <<
	template<class T>
	struct bitwise_leftshift : public std::binary_function<T, T, T>
	{
		inline
		T operator()(T const& l, T const& r) const
		{
			return (l << r);
		}
	};

	// Bitwise >>
	template<class T>
	struct bitwise_rightshift : public std::binary_function<T, T, T>
	{
		inline
		T operator()(T const& l, T const& r) const
		{
			return (l >> r);
		}
	};

	// Bitwise &
	template<class T>
	struct bitwise_and : public std::binary_function<T, T, T>
	{
		inline
		T operator()(T const& l, T const& r) const
		{
			return (l & r);
		}
	};

	// Bitwise |
	template<class T>
	struct bitwise_inclusive_or : public std::binary_function<T, T, T>
	{
		inline
		T operator()(T const& l, T const& r) const
		{
			return (l | r);
		}
	};

	// Bitwise ^
	template<class T>
	struct bitwise_exclusive_or : public std::binary_function<T, T, T>
	{
		inline
		T operator()(T const& l, T const& r) const
		{
			return (l ^ r);
		}
	};

//....................................................................................................................................................................................

	// Functor-classes for the different kinds of assignment.

	// Assignment =
	template<class T>
	struct assign : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l = r);
		}
	};

	// Assignment +=
	template<class T>
	struct assign_plus : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l += r);
		}
	};

	// Assignment -=
	template<class T>
	struct assign_minus : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l -= r);
		}
	};

	// Assignment *=
	template<class T>
	struct assign_multiplies : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l *= r);
		}
	};

	// Assignment /=
	template<class T>
	struct assign_divides : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l /= r);
		}
	};

	// Assignment %=
	template<class T>
	struct assign_modulus : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l %= r);
		}
	};

	// Assignment &=
	template<class T>
	struct assign_bitwise_and : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l &= r);
		}
	};

	// Assignment |=
	template<class T>
	struct assign_bitwise_or : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l |= r);
		}
	};

	// Assignment ^=
	template<class T>
	struct assign_bitwise_xor : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l ^= r);
		}
	};

	// Assignment <<=
	template<class T>
	struct assign_bitwise_lshift : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l <<= r);
		}
	};

	// Assignment >>=
	template<class T>
	struct assign_bitwise_rshift : public std::binary_function<T, T, T>
	{
		inline
		T& operator()(T& l, T const& r) const
		{
			return (l >>= r);
		}
	};

//....................................................................................................................................................................................

	// Power of 2.
	template <typename T>
	struct power2 : public std::unary_function<T, T>
	{
		T operator()(T const& x) const
		{
			return x*x;
		}
	};

	// Power of 4.
	template <typename T>
	struct power4 : public std::unary_function<T, T>
	{
		T operator()(T const& x) const
		{
			power2<T> f2;

			T x2 = f2(x);
			T x4 = f2(x2);

			return x4;
		}
	};

	// Power of 8.
	template <typename T>
	struct power8 : public std::unary_function<T, T>
	{
		T operator()(T const& x) const
		{
			power2<T> f2;
			power4<T> f4;

			T x4 = f4(x);
			T x8 = f2(x4);

			return x8;
		}
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
