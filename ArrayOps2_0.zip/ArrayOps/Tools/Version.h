//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Version
//
//	ArrayOps version definitions. You may use #if-clauses to ensure
//	your own source-code is compatible with the given ArrayOps version.
//
//....................................................................................................................................................................................

#pragma once

// ArrayOps version 2.0
#define ARRAYOPS_VERSION_MAJOR 2
#define ARRAYOPS_VERSION_MINOR 0
