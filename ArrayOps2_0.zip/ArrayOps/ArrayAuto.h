//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ArrayAuto
//
//	Data-structure for a resizable array, that automatically
//	resizes to the size of the right-hand expression in an
//	assignment. It derives from the Array-class for its actual
//	storage.
//
//	When resizing the array in an overwriting assignment, we do
//	not copy the elements first. But when resizing the array in
//	an accumulative assignment (e.g. +=, *=, etc.), we copy the
//	elements before performing the assignment. This functionality
//	is implemented in the AOp_MakeAssignAuto macro, and is the
//	only real difference between the Array- and ArrayAuto-classes.
//
//	By default, parallellism is turned on for this class.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Array.h>
#include <ArrayOps/Macros/AOp_MakeAssignAuto.h>
#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The ArrayAuto-class that you should instantiate.
	template <class T, bool Parallel=true>
	class ArrayAuto : public Array<T, Parallel>
	{
	public:
		ArrayAuto () : Array<T, Parallel>() {}
		ArrayAuto (unsigned int size) : Array<T, Parallel>(size) {}

		ArrayAuto (ArrayAuto const& x) : Array<T, Parallel>()
		{
			*this = x;
		}

		template <class S1>
		ArrayAuto (Expr<T, S1> const& x) : Array<T, Parallel>()
		{
			*this = x;
		}

		// Macro that makes overloadings for the assignment operators.
		// This macro is specialized for the ArrayAuto-class.
		AOp_MakeAssignAuto(ArrayAuto);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
