//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	ArrayMini
//
//	Data-structure used for storing (small) arrays whose size is
//	known at compile-time. By default, parallellism is turned off.
//
//....................................................................................................................................................................................

#pragma once

#include <ArrayOps/Bases/ArrayBase.h>
#include <ArrayOps/Macros/AOp_MakeAssign.h>
#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................

	// The base-class containing storage and basic functions.
	template <class T, unsigned int kSize>
	class	ArrayMini_Imp
	{
	public:
		ArrayMini_Imp				() {}

		// Element lookup.
		inline T&		operator[]	(unsigned int i)
		{
			assert(i<kSize);
			return mStorage[i];
		}

		// Element lookup, const.
		inline
		T const&		operator[]	(unsigned int i) const
		{
			assert(i<kSize);
			return mStorage[i];
		}

		// Size of array.
		inline
		unsigned int	Size		() const { return kSize; }
		inline bool		IsSized		() const { return true; }

	protected:
		T			mStorage[kSize];
	};

//....................................................................................................................................................................................

	// The actual ArrayMini-class that you should instantiate.
	template <class T, unsigned int kSize, bool Parallel=false>
	class ArrayMini : public ArrayBase<T, ArrayMini_Imp<T, kSize>, Parallel>
	{
	public:
		ArrayMini () : ArrayBase<T, ArrayMini_Imp<T, kSize>, Parallel>() {}

		// Macro that makes overloadings for the assignment operators.
		AOp_MakeAssign(ArrayMini);
	};

//....................................................................................................................................................................................
} //end namespace ArrayOps
