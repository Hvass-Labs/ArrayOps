//....................................................................................................................................................................................
//
//	ArrayOps - Vector Computation Library For C++.
//	Copyright (C) 2005-2006 Magnus Erik Hvass Pedersen.
//	Published under the GNU Lesser General Public License.
//	Please see the file license.txt for license details.
//	ArrayOps on the internet: http://www.Hvass-Labs.org/
//
//	Test program.
//
//	Defines the entry point for the console application.
//	This program performs various tests on ArrayOps.
//	You should manually check the results in debug-mode
//	and save the output. Then compile and run the program
//	in release-mode, and compare the output of the two.
//
//....................................................................................................................................................................................

#include "stdafx.h"

#include <ArrayOps/Array.h>
#include <ArrayOps/ArrayMini.h>
#include <ArrayOps/ArrayUse.h>
#include <ArrayOps/ArrayAuto.h>

#include <ArrayOps/Tools/Functional.h>

#include <functional>
#include <iostream>
#include <cassert>

using namespace ArrayOps;
using std::cout;
using std::endl;

template <class T, class S>
void DeleteMe(Expr<T, S>* x)
{
	delete x;
}

template <typename T>
class Adder : public std::unary_function<T,T>
{
public:
	Adder(T const& init) : std::unary_function<T,T>(), mSum(init) {}
	Adder() : std::unary_function<T,T>(), mSum(0) {}

	inline T const& operator() (T const& x)
	{
		mSum += x;
		return mSum;
	}

	inline T const& operator() ()
	{
		return mSum;
	}

protected:
	T	mSum;
};

template <typename TArg, typename TRes=double>
class Average : public std::unary_function<TArg,TRes>
{
public:
	Average() : std::unary_function<TArg,TRes>(), mSum(0), mCount(0) {}

	inline void operator() (TArg const& x)
	{
		mCount++;
		mSum(x);
	}

	inline TRes operator() ()
	{
		assert(mCount>0);

		return ((TRes) mSum())/mCount;
	}

protected:
	Adder<TArg>		mSum;
	unsigned int	mCount;
};

template <class T>
class MyPow2 : public std::unary_function<T, T>
{
public:
	MyPow2() : std::unary_function<T, T>() {}

	inline
	T operator() (T const& x) const { return x*x; }
};

int MyPow2F(int x) { return x*x; }

class Sqrt : public std::unary_function<int, double>
{
public:
	Sqrt() : std::unary_function<int, double>() {}

	inline
		double operator() (int const& x) const { return std::sqrt((double)x); }
};

double SqrtF(int x) { return std::sqrt((double)x); }

template <class T, class S>
std::ostream& operator<<(std::ostream& out, Expr<T, S> const& expr)
{
	const unsigned int kSize = expr.Size();

	for (unsigned int i=0; i<kSize; i++)
	{
		out << expr[i] << " ";
	}

	return out;
}

template <class T, class S, bool Parallel>
void Ramp(ArrayBase<T, S, Parallel>& arr, T const& a=1, T const& b=0)
{
	for (unsigned int i=0; i<k; i++)
	{
		arr[i] = a*i+b;
	}
}

template <class T, class S, bool Parallel, class Q>
void Assign(ArrayBase<T, S, Parallel>& arr, Q const& a)
{
	assert(a);
	const unsigned int k=arr.Size();

	for (unsigned int i=0; i<k; i++)
	{
		arr[i] = a[i];
	}
}

template <class T, class S, bool Parallel, class Q>
bool Equal(ArrayBase<T, S, Parallel> const& arr, Q const& a)
{
	assert(a);
	const unsigned int k=arr.Size();
	bool retVal = true;

	for (unsigned int i=0; i<k && retVal; i++)
	{
		retVal &= (arr[i] == a[i]);
	}

	return retVal;
}

template <class T, class S, bool Parallel, class Q>
void IsEqual(ArrayBase<T, S, Parallel> const& arr, Q const& a)
{
	assert(Equal(arr, a));
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Testing ArrayOps version " << ARRAYOPS_VERSION_MAJOR << "." << ARRAYOPS_VERSION_MINOR << endl;

	// Instantiate various kinds of arrays.
	const unsigned int k = 5;
	Array<int> A(k), B(k);
	Array<int, false> C(k);
	ArrayMini<int, k> D, E, F;
	//ArrayMini<int, 0> R; // This should cause a compiler error!
	int arrG[k], arrH[k];
	ArrayUse<int> G(arrG, k), H(arrH, k);
	ArrayAuto<int> K(k);
	ArrayAuto<int, false> L;
	ArrayAuto<int, false> M(L);
	Array<double> P(k);
	Array<float> Q(k);
	Array<bool> Z(k);
	const Array<int> kA(k);

	// Test resizing of initially empty array.
	C.Resize(k);

	// Initialize array manually.
	for (int i=0; i<k; i++)
	{
		A[i] = i+1;
	}

	cout << A << endl;

	// Test assignment operators with identical and different kinds of arrays.
	B = kA; cout << B << endl;
	B = A; cout << B << endl;
	C = B = A; cout << B << endl << C << endl;
	D = C; cout << D << endl;
	G = D; cout << G << endl;
	E = D; cout << E << endl;
	H = G; cout << H << endl;
	K = G; cout << K << endl;
	L = K; cout << L << endl;
	M = L; cout << M << endl;

	cout << endl;

	// Test more kinds of ArrayAuto instantiations.
	ArrayAuto<int, false> N(L); cout << N << endl;
	ArrayAuto<int, false> O(A*2+B%3); cout << O << endl;
	P = 1.5*StaticCast<double>(O); cout << P << endl;

	cout << endl;

	// Test destruction of an ArrayAuto-object (use debugger for this).
	{
		ArrayAuto<double, false> PP(P); cout << PP << endl;
	}

	cout << endl;

	// Test summation etc. functions.
	cout << Sum(A) << endl;
	cout << Product(A) << endl;
	cout << Norm(A) << endl;
	cout << Reduce<double>::Norm(A) << endl;
	cout << Mean(A) << endl;
	cout << Mean(O) << endl;
	cout << Mean(A+O) << endl;
	cout << Reduce<float>::Mean(A*2+O+1) << endl;
	cout << Variance(A) << endl;
	cout << Variance(O) << endl;
	cout << Variance(3*A+2*O) << endl;
	cout << Reduce<float>::Variance(2*A+3*O) << endl;
	cout << Variance(P) << endl;

	cout << endl;

	// Test reductions.
	cout << ReduceAll<Adder<int> >(A) << endl;
	cout << ReduceAll<Adder<int> >(2*A+3*B) << endl;
	cout << ReduceAll(A+1, Adder<int>()) << endl;
	cout << ReduceAll<Average<int, double>, double>(A+1) << endl;
	cout << ReduceAll<double>(A+2, Average<int>()) << endl;

	cout << endl;

	// Test slice, cycle, reverse.
	cout << A.Slice(2,2) << endl;
	cout << A.Cycle(3) << endl;
	cout << A.Reverse() << endl;
	Array<int>::ArrayReverse RevA = A.Reverse();
	cout << RevA << endl;
	Array<int>::ArrayReverse::ArrayCycle CycA = RevA.Cycle(1);
	cout << CycA << endl;
	A.Slice(2,2) = A.Slice(3,2); cout << A << endl;
	A.Slice(2,2) += A.Slice(3,2); cout << A << endl;
	A.Slice(2,2) = A.Reverse().Slice(3,2); cout << A << endl;
	A.Slice(2,2) = B.Reverse().Slice(3,2); cout << A << endl;
	A.Cycle(2) = A.Cycle(3); cout << A << endl;
	A.Cycle(2) = A.Cycle(3).Cycle(2); cout << A << endl;
	A.Reverse() = A.Reverse(); cout << A << endl;
	A.Reverse() = A.Reverse().Reverse(); cout << A << endl;

	cout << endl;

	// Test that assignment operators do not mess with source-arrays.
	B *= 2; cout << B << endl << A << endl;
	C *= 3; cout << C << endl << B << endl;
	D *= 4; cout << D << endl << A << endl;
	E *= 5; cout << E << endl << D << endl;
	G *= 6; cout << G << endl << H << endl;
	M *= 7; cout << M << endl << L << endl;

	cout << endl;

	// Test basic operators, (mostly) non-recursive expressions.
	A += B + C; cout << A << endl;
	A -= C * D; cout << A << endl;
	A *= E / B; cout << A << endl;
	A %= (G+1); cout << A << endl;
	A = -A; cout << A << endl;
	B = A*2-A[0]*4; cout << B << endl;
	C = -B+10; cout << C << endl;
	A = C << 3; cout << A << endl;
	C = A >> 2; cout << C << endl;
	A = B & C; cout << A << endl;
	A = B | C; cout << A << endl;
	A = B ^ C; cout << A << endl;
	B = A * A; cout << B << endl;

	cout << endl;

	// Test element lookup.
	cout << (A+2*B+C)[0] << endl;
	cout << A[0]+2*B[0]+C[0] << endl;
	cout << A[0] << endl;
	A.at(0) = A[0]+1; cout << A.at(0) << endl;

	try
	{
		cout << A.at(k) << endl;
	}
	catch (...)
	{
		cout << "Index out of bounds!" << endl;
	}

	cout << endl;

	// Test implementation of size-queries (see assembly).
	cout << A.IsSized() << endl;
	cout << B.IsSized() << endl;
	cout << C.IsSized() << endl;
	cout << (A+B*3).IsSized() << endl;
	cout << (B+C*4).IsSized() << endl;
	cout << (C+D*5).IsSized() << endl;
	cout << A.Size() << endl;
	cout << B.Size() << endl;
	cout << C.Size() << endl;
	cout << (A*2+3*B).Size() << endl;
	cout << (5*B+1*C).Size() << endl;
	cout << (6*C+-1*D).Size() << endl;

	cout << endl;

	// Test accumulative assignment operators.
	A += B-C; cout << A << endl;
	A -= C-D; cout << A << endl;
	A *= 1+(128*D)/E; cout << A << endl;
	A &= 1023; cout << A << endl;
	A /= B+1; cout << A << endl;
	A |= 73; cout << A << endl;
	A %= 64; cout << A << endl;
	A ^= B; cout << A << endl;
	A <<= 2; cout << A << endl;
	A >>= 1; cout << A << endl;

	cout << endl;

	// Test basic logical operators.
	Z = B == C; cout << Z << endl;
	Z = B != C; cout << Z << endl;
	Z = A+B == A+B; cout << Z << endl;
	Z = B < C; cout << Z << endl;
	Z = B <= C; cout << Z << endl;
	Z = B > C; cout << Z << endl;
	Z = B >= C; cout << Z << endl;

	cout << endl;

	// Test basic logical operators.
	Z = (A >= B) && (B < C); cout << Z << endl;
	Z = (A < B) || (B < C); cout << Z << endl;
	Z = !((A < B) || false || (B < C)) && true; cout << Z << endl;

	cout << endl;

	// Test basic operators, recursive expressions.
	A /= 1 + D % E; cout << A << endl;
	A = B + C + D + E; cout << A << endl;
	B = C * D - E / (F+1); cout << B << endl;

	cout << endl;

	// Test Eval-functions, unary.
	MyPow2<int> p;
	Sqrt s;
	B = A;
	A = Eval1(B, p); cout << A << endl;
	P = Eval1<double, int, Sqrt>(B+1, s); cout << P << endl;
	P = Eval1<double, int, Sqrt>(B+2, Sqrt()); cout << P << endl;
	A = Eval1<MyPow2<int> >(B+2); cout << A << endl;
	P = Eval1<Sqrt, double>(B-1); cout << P << endl;
	A = Eval1(B-2, &MyPow2F)+C; cout << A << endl;
	P = Eval1(B+3, &SqrtF)+0.001*P; cout << P << endl;

	cout << endl;

	// Test type-matching.
	P = 123.0; cout << P << endl;
	//P = A; cout << P << endl; // Should cause a compile-error!
	//Q = P; cout << Q << endl; // Should cause a compile-error!

	cout << endl;

	// Test casting.
	P = StaticCast<double>(A) + 0.5; cout << P << endl;
	//P = StaticCast<double>(StaticCast<float>(B) - 0.5); cout << P << endl; // Should generate a compile-time error!
	P = StaticCast<double>(StaticCast<float>(B) - (float)0.5); cout << P << endl; // Should generate a compile-time error!

	cout << endl;

	// Test math functions.
	Q = StaticCast<float>(P); cout << Q << endl;
	P = pow(sin(3.14/StaticCast<double>(Q)), 2.0); cout << P << endl;
	P += pow(cos(3.14/StaticCast<double>(Q)), 2.0); cout << P << endl;
	P = sqrt(StaticCast<double>(A)); cout << P << endl;
	P = pow2(1.0/P+1.0)+2.0; cout << P << endl;
	P = pow4(P); cout << P << endl;
	P = pow8(P); cout << P << endl;

	cout << endl;

	// Test size-matching.
	B.Resize(k+1);
	//B = A; cout << B << endl; // Should cause an assert()-error in debug-mode!
	B.Slice(0, k) = A; cout << B << endl;
	B.Resize(k);
	B = A; cout << B << endl;
	B.ResizeCopy(k); cout << B << endl;
	B.ResizeCopy(k+1); cout << B << endl;
	B.ResizeCopy(k); cout << B << endl;
	cout << L << endl;
	K.Resize(k+1);
	K = A*2+B*3; cout << K << endl;
	//L += K+B.Slice(0, k-1); cout << L << endl; // Should cause an assert()-error in debug-mode!
	L += B.Slice(0, k-1); cout << L << endl;

	cout << endl;

	// Test destruction of an object.
	// Use debugger for this.
	{
		Array<int>* DelA = new Array<int>(k);
		Array<int>* DelB = new Array<int>(k);

		DeleteMe(DelA);
		delete DelB;

		ArrayAuto<int>* DelC = new ArrayAuto<int>(k);
		ArrayAuto<int>* DelD = new ArrayAuto<int>(k);

		DeleteMe(DelC);
		delete DelD;
	}

	return 0;
}

